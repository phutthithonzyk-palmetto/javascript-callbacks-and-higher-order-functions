# hackhours-answers
Hack hours answer repository. 

## How-to-Access-to-Answer-Branches

* To view answers, checkout to branch named as Hack Hours Repository's name 
* For example, if you want the answer for this repo of yours "js-hh-variables-mind-test"
* Type ``` git checkout js-hh-variables ```
* and Voilà!
